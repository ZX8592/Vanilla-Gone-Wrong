# Generated from the approved checklist; Java 26.3.
data modify storage havoc:dimension falling set value {"id":"minecraft:bubble_coral_fan"}
data modify storage havoc:dimension falling.properties.waterlogged set value "false"
