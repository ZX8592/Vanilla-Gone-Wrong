# Generated from the approved checklist; Java 26.3.
data modify storage havoc:dimension falling set value {"id":"minecraft:brain_coral"}
data modify storage havoc:dimension falling.properties.waterlogged set value "false"
